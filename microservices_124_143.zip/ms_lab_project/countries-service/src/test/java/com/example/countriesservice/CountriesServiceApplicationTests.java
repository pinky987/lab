package com.example.countriesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountriesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
