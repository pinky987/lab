package com.example.travelogueservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelogueServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
