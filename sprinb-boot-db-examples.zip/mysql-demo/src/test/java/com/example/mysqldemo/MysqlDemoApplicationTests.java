package com.example.mysqldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysqlDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
